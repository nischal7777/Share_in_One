module.exports = {
  plugins: ['tailwindcss'],
};