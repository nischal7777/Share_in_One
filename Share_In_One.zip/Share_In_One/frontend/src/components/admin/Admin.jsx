import React from 'react';
import Navbar from './Navbar';

function Admin() {
	return (
		<>
			<Navbar />
		</>
	);
}

export default Admin;
